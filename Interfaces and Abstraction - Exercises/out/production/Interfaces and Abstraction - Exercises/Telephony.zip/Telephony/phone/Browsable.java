package Telephony.phone;

public interface Browsable {
    String browse();
}
