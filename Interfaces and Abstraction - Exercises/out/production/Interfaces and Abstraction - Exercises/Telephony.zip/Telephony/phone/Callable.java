package Telephony.phone;

public interface Callable {
    String call();
}
