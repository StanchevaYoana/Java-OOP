package hero;

public class Main {

    public static void main(String[] args) {
        BladeKnight bladeKnight = new BladeKnight("New Hero",25);
        System.out.println(bladeKnight.toString());
    }
}
